#!/usr/bin/env python3
"""Dependency-free structural validator for Final GU Generation Contract JSON."""

from __future__ import annotations

import json
import sys
from pathlib import Path

REQUIRED_TOP_LEVEL = [
    "contract_version",
    "status",
    "source_atoms",
    "time_capacity_seconds",
    "scene_purpose",
    "scene_question",
    "visible_task",
    "world_space",
    "character_state",
    "director_intent",
    "shot_coverage",
    "beat_chain",
    "camera_contract",
    "sound_contract",
    "permissions",
    "continuity_out",
    "gates",
]

REQUIRED_GATES = ["source_coverage", "ai_readability", "prompt_compiler_permission"]


def validate_contract(data: object) -> list[str]:
    errors: list[str] = []
    if not isinstance(data, dict):
        return ["root must be a JSON object"]

    for key in REQUIRED_TOP_LEVEL:
        if key not in data:
            errors.append(f"missing required field: {key}")

    if data.get("status") != "FROZEN":
        errors.append("status must be FROZEN")

    source_atoms = data.get("source_atoms")
    if not isinstance(source_atoms, list) or not source_atoms:
        errors.append("source_atoms must be a non-empty array")
    else:
        seen: set[str] = set()
        for index, atom in enumerate(source_atoms):
            if not isinstance(atom, dict):
                errors.append(f"source_atoms[{index}] must be an object")
                continue
            atom_id = atom.get("id")
            if not isinstance(atom_id, str) or not atom_id.strip():
                errors.append(f"source_atoms[{index}].id must be non-empty")
            elif atom_id in seen:
                errors.append(f"duplicate source atom id: {atom_id}")
            else:
                seen.add(atom_id)
            if not isinstance(atom.get("text"), str) or not atom["text"].strip():
                errors.append(f"source_atoms[{index}].text must be non-empty")
            if atom.get("coverage") not in {"VISIBLE", "CONTEXT"}:
                errors.append(f"source_atoms[{index}].coverage must be VISIBLE or CONTEXT")

    capacity = data.get("time_capacity_seconds")
    if not isinstance(capacity, (int, float)) or isinstance(capacity, bool) or capacity <= 0:
        errors.append("time_capacity_seconds must be > 0")

    for key in ("scene_purpose", "scene_question", "visible_task"):
        if not isinstance(data.get(key), str) or not data.get(key, "").strip():
            errors.append(f"{key} must be a non-empty string")

    for key in ("shot_coverage", "beat_chain"):
        value = data.get(key)
        if not isinstance(value, list) or not value:
            errors.append(f"{key} must be a non-empty array")

    permissions = data.get("permissions")
    if not isinstance(permissions, dict):
        errors.append("permissions must be an object")
    else:
        for key in ("LOCK", "GUIDE", "FREE"):
            if not isinstance(permissions.get(key), list):
                errors.append(f"permissions.{key} must be an array")

    gates = data.get("gates")
    if not isinstance(gates, dict):
        errors.append("gates must be an object")
    else:
        for gate in REQUIRED_GATES:
            if gates.get(gate) != "PASS":
                errors.append(f"gates.{gate} must be PASS")

    return errors


def main(argv: list[str]) -> int:
    if len(argv) != 2:
        print("usage: validate_contract.py <contract.json>", file=sys.stderr)
        return 2

    path = Path(argv[1])
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError:
        print(f"ERROR: file not found: {path}", file=sys.stderr)
        return 2
    except json.JSONDecodeError as exc:
        print(f"ERROR: invalid JSON: {exc}", file=sys.stderr)
        return 2

    errors = validate_contract(data)
    if errors:
        print("INVALID")
        for error in errors:
            print(f"- {error}")
        return 1

    print("VALID")
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
