# Compiler Boundary

The frozen Final GU Generation Contract is the semantic source of truth.

Do not re-read raw narrative or old prompt drafts to reinterpret a frozen field. Upstream approved rewrites supersede earlier material.

## Source coverage

When `source_atoms` exist:

- cover every approved atom in the current unit or explicitly retain it as contextual/non-visible;
- add zero unsourced plot-critical facts;
- rewrite zero locked facts;
- preserve approved dialogue exactly unless the contract explicitly marks wording as adaptable.

## Time windows

Treat shot/beat time ranges as rhythm budgets rather than frame-accurate edit commands unless the contract explicitly requires frame accuracy.

## Reference assets

For every `@reference`, state what it is allowed to control and what it is not allowed to control. A blocking map, for example, may control position, path, height relation, camera sector, and orientation while being forbidden from controlling character appearance or visual style.
