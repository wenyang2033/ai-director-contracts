---
name: prompt-compiler
description: Compile one frozen Final GU Generation Contract into one generation-ready video prompt while preserving source facts, dialogue, beat order, shot coverage, continuity, camera intent, sound, and LOCK/GUIDE/FREE permissions. Use only when the final contract is frozen and its gates pass; block instead of rewriting or compressing upstream decisions.
---

# Prompt Compiler

## Goal

Compile, do not create. Convert one frozen generation contract into one coherent prompt for a target video model without changing approved semantics.

Read `references/compiler-boundary.md` before compiling.

## Preconditions

Require:

- one frozen Final GU Generation Contract;
- source coverage gate passed;
- AI-readability gate passed;
- prompt compiler permission passed;
- all required asset bindings available or explicitly optional;
- target duration/capacity compatible with the approved beat chain.

If any precondition fails, return `BLOCKED` and identify the owning upstream stage.

## Allowed transformations

- turn structured fields into natural model-readable prose;
- merge redundant wording without deleting meaning;
- reorder wording inside the same beat when causality and visible order stay unchanged;
- translate abstract approved directing into explicit observable action when the generation contract already defines that meaning;
- adapt syntax to a target model without changing the core semantic contract.

## Forbidden transformations

- add plot or world facts;
- remove approved beats;
- change beat order;
- rewrite or shorten locked dialogue;
- redesign camera coverage;
- invent new transitions to solve a duration problem;
- hide capacity overflow by demanding faster editing;
- use old drafts, raw source, or previous prompts to override the frozen contract.

## Compilation order

Prefer this structure unless a target provider requires a different surface syntax:

```text
Overall visual baseline
Era / world context
Current generation-unit content
Continuity inheritance (when needed)
Reference assets and their exact responsibilities
Scene / spatial structure
Lighting
Shot / beat action chain
Sound plan
Minimal necessary prohibitions
```

Keep the action/shot chain as the dominant information block.

## Capacity gate

If approved content cannot fit the requested duration:

1. stop compilation;
2. report capacity conflict;
3. return the issue upstream for an approved generation-unit split;
4. compile only after each split unit has its own frozen contract.

## Output

Return exactly one prompt for exactly one generation unit, plus a short machine-readable compiler status outside the prompt if the calling environment supports metadata.
