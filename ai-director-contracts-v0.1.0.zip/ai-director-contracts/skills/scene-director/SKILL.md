---
name: scene-director
description: Convert an approved scene/story contract into executable director-level blocking, shot coverage, composition, reveal permissions, anchor visibility, rhythm, and a director gate. Use when story facts are already approved and the next task is HOW TO SHOW the scene without changing plot, dialogue, canon, motives, or world rules.
---

# Scene Director

## Goal

Direct an already-approved scene. Decide how the audience sees and understands it without rewriting what happens or why.

Read `references/coverage-contract.md` when defining shots, anchors, or composition gates.

## Required input

Require an approved upstream scene/story contract containing enough information to identify:

- scene purpose and question;
- approved plot facts and dialogue locks;
- character objective and visible task;
- relevant world/canon facts;
- reveal/knowledge constraints;
- continuity-in state.

If these are materially missing or contradictory, return a blocking diagnostic. Do not invent upstream facts.

## Workflow

1. Restate the scene question and visible task in observable terms.
2. Define completion condition and movement intent.
3. Define blocking only where it expresses power, danger, relationship, objective, access, or path constraints.
4. Translate hidden truth into performance behavior without explanatory acting.
5. Set camera reveal permission and clue budget.
6. Design shot coverage. Give every principal shot one dominant narrative function.
7. Assign subject priority, scale, depth roles, camera sector, and anchor visibility.
8. Require a real composition change between adjacent principal shots when the narrative function changes.
9. Run the composition repetition gate.
10. Mark `AUXILIARY MAP REQUIRED` only when spatial complexity justifies it.
11. Return a director gate result: `PASS` or `BLOCKED` with reasons.

## Hard boundaries

- Do not rewrite plot, approved dialogue, canon, abilities, or motivation.
- Do not let the camera reveal information earlier than the approved reveal schedule.
- Do not force every character or anchor into every shot for continuity.
- Do not treat higher physical position as automatic permission for giant foreground dominance.
- Do not defer shot coverage decisions to the prompt compiler.
- If a new story fact is required, emit `UPSTREAM CHANGE REQUEST` and stop that branch.

## Output

Return:

```text
Scene Question
Visible Task
Completion Condition
Blocking
Performance Truth
Camera Reveal Permission
Clue Budget
Entry Evidence Chain
Anchor Visibility Policy
Shot Coverage / Composition Contract
Sound / Rhythm
Auxiliary Map Requirement
Composition Repetition Gate
Director Gate
```

Every principal shot should include:

```text
Shot ID
Shot Function
Camera Sector
Primary Subject
Secondary Subject
Subject Scale
Foreground Role
Midground Role
Background Role
Anchor Visibility
Occlusion Permission
Composition Intent
Composition Change From Previous
Exit State
```
