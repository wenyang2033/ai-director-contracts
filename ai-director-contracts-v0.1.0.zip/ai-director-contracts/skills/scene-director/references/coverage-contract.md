# Coverage Contract Reference

## Anchor visibility

For each story-relevant landmark or spatial anchor, define:

```text
Anchor Name
Story Function
Strong Visibility
Weak Visibility
Hidden
Composition Restriction
```

Interpretation:

- `STRONG`: the anchor carries story information in this shot and must read clearly.
- `WEAK`: the anchor may remain as a low-salience orientation cue.
- `HIDDEN`: the shot is allowed to exclude the anchor completely.

World existence does not imply shot visibility.

## Composition repetition gate

Block progression if the plan repeatedly uses any of these without a story reason:

- giant foreground character + tiny distant opponent;
- the same landmark on the central vanishing point;
- all characters and all anchors visible in every shot;
- repeated wide shots only to re-prove already-established space;
- reverse shots that only swap foreground characters while preserving the same visual grammar;
- reaction/evidence shots cluttered by unnecessary secondary subjects;
- action without an independent visual result shot.

## Auxiliary map trigger

Recommend a blocking/camera map when one or more conditions materially affect comprehension:

- multi-character spatial relations drive the scene;
- strong height differences;
- pursuit, interception, flanking, or blocked paths;
- multiple navigation anchors;
- important occlusion or eyelines;
- camera coverage spans several spatial sectors;
- prior generation shows repeated composition, scale errors, or spatial drift.

A map is a spatial reference, not an art asset. It must not transfer character appearance, architectural style, text, or diagram colors into generation.
