---
name: generation-designer
description: Translate an approved director scene design into model-readable generation constraints for world space, action causality, targets, orientation, scale, continuity, camera behavior, composition execution, sound, and final state. Use after director coverage is approved and before any final video prompt is written; never use it to redesign the scene.
---

# Generation Designer

## Goal

Translate approved directing into executable generation semantics. Preserve meaning, coverage, and continuity while making each beat observable to a video model.

Read `references/generation-contract.md` for translation rules and gate criteria.

## Required input

Require approved director output with shot coverage/composition decisions, plus approved story/canon facts and continuity-in state.

If the director layer has not resolved a required shot, anchor, target, reveal, or spatial contradiction, return a blocking diagnostic instead of inventing a solution.

## Workflow

1. Lock world space before action space; lock action space before camera space.
2. Convert subtext and director semantics into observable behavior, eyelines, action order, spatial relation, and result.
3. Keep one dominant task per short beat.
4. Assign salience: `Primary`, `Secondary`, `Background`.
5. For every key action, lock actor, target, target type, orientation, path, and result.
6. Separate character scale from effect/domain scale.
7. Preserve stable VFX signatures where a recurring effect exists.
8. Translate director-approved coverage into model-readable composition execution.
9. Apply anchor exposure control exactly as approved.
10. Select continuity mode: hard visual, state continuity, or scene reset with continuity.
11. Produce a machine-readable final output state.
12. Run the AI-readability gate.

## Hard boundaries

- Do not redesign shot coverage.
- Do not promote a `HIDDEN` anchor back into visibility.
- Do not turn a `WEAK` anchor into the central visual subject.
- Do not flatten different approved shots into one repeated poster composition.
- Do not invent plot facts to make a prompt easier.
- Treat an approved generated result as reality state for subsequent continuity.

## Output

Return a generation-design artifact containing:

```text
Generation Goal
Continuity Mode
Asset Strategy
World Space
Scale Locks
Character State Cards
Visual / VFX Signatures
Knowledge / Reveal Locks
AI Readability Translation
Composition Execution
Anchor Exposure Control
Beat Contract
Target / Orientation Locks
Camera Behavior Contract
Sound Contract
Auxiliary Map
LOCK / GUIDE / FREE
AI Gate
Final Output State
```
