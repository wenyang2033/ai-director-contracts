# Generation Contract Reference

## Translation rules

### Subtext translation
Turn internal states into visible evidence: timing, hesitation, gaze, posture, distance, action order, object handling, or withholding.

### One beat, one dominant task
A beat can contain secondary detail, but the model should have one primary information task.

### Target lock
For every consequential action, make the relation explicit:

```text
Actor
Action
Target
Target Type
Body Orientation
Gaze / Tool Orientation
Movement Path
Contact / Result
Residual State
```

### Environment causality
Environmental damage or movement must be the visible consequence of an action or established world mechanism, not unexplained spectacle.

### Composition execution
For every approved shot, preserve:

- primary visual subject;
- secondary subject;
- camera sector;
- subject scale;
- foreground/midground/background roles;
- anchor visibility;
- occlusion permission;
- composition exit.

## Continuity modes

- `HARD_VISUAL_CONTINUITY`: directly inherit an approved previous frame/reference.
- `STATE_CONTINUITY`: inherit observable state but do not bind to an exact image.
- `SCENE_RESET_WITH_CONTINUITY`: rebuild a new scene while carrying only required facts.

`Reality State > Plan State`: once a take is accepted, its observable result outranks earlier planning assumptions.

## AI gate

Pass only when:

- director subject priority survives translation;
- anchor visibility is respected shot by shot;
- height relationships are not repeatedly encoded as giant foreground/small background staging;
- world anchors are not forced into every shot;
- approved coverage diversity remains visible;
- auxiliary maps affect only spatial/camera relations, not character appearance or art direction;
- final state is explicit enough for the next generation unit to inherit.
