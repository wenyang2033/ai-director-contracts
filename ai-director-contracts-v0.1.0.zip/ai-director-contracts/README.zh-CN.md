# AI Director Contracts

**面向 AI 影视生产的“契约优先”Agent Skills：把导演决定冻结下来，再交给生成模型执行。**

AI 视频工作流最容易出错的地方往往不是某一个模型，而是“层与层之间的交接”：下游偷偷改剧情、Prompt 阶段临时发明镜头、连续性被重新解释、复杂场次不断退化成同一种构图。

本项目把这类交接改成可审查、可验证的契约，首版包含三个 Skill：

1. `scene-director`：只做导演场次设计，负责 Blocking、Shot Coverage、构图变化、Reveal 权限和导演门禁。
2. `generation-designer`：把已批准导演设计翻译成模型可执行的空间、动作、连续性、显著性和摄影机约束，不重新导演。
3. `prompt-compiler`：只读取冻结后的 Final GU Generation Contract，把它编译成一条生成提示词，不改剧情、不删 Beat、不改对白、不重新设计镜头。

核心原则：

> **剧本决定“发生什么、为什么”；导演决定“观众如何看懂”；AI 生成设计决定“模型如何执行”；Prompt Compiler 只负责翻译冻结后的决定。**

## 解决的问题

- SOURCE / Dialogue Lock：避免下游恢复旧稿或偷改台词；
- Shot Coverage Contract：镜头先有叙事任务，再谈景别和运镜；
- Anchor Visibility：地标存在于世界，不等于每镜都必须出现；
- Composition Repetition Gate：提前阻止“大前景人物 + 小远景人物”等构图重复；
- Target / Orientation：锁定动作主体、目标、朝向、路径和结果；
- Continuity Modes：区分硬尾帧继承、状态继承和新场重建；
- Reality State > Plan State：验收后的真实生成结果成为下一段事实；
- LOCK / GUIDE / FREE：明确每个字段的修改权限；
- Final Contract：Prompt 阶段只读唯一最终契约，不回头重新解释过程文档。

## 流程

```text
批准后的剧情 / 场次事实
        ↓
Scene Contract（WHAT + WHY）
        ↓
scene-director
        ↓
generation-designer
        ↓
Final GU Generation Contract（FROZEN）
        ↓
prompt-compiler
        ↓
单次生成 Prompt
        ↓
生成结果验收 → Reality State → 定点返修
```

任何下游发现上游缺失或冲突，都应返回阻塞诊断，而不是“顺手补一个看起来合理的答案”。

## 快速验证

```bash
python3 scripts/validate_contract.py examples/final-gu-contract.valid.json
python3 -m unittest discover -s tests -p 'test_*.py'
```

验证器和测试不需要 API Key。

## 当前状态

`v0.1.0`：三个核心 Skills + Final GU Contract schema + validator + tests + 示例。

首版刻意保持 provider-neutral，后续再加入不同视频生成模型的适配层，不把某个模型的参数污染到核心导演契约。

## 开源边界

仓库只接受可公开、可再分发的示例。不要提交客户剧本、未发布项目、真实 API Key、私有素材 URL 或其他生产机密。

## License

MIT。
