# Architecture

## Ownership model

AI Director Contracts uses a staged ownership model so an agent cannot solve every problem by rewriting the final prompt.

### 1. Approved story contract

Input from an upstream story process. It owns plot causality, approved dialogue, character motivation, reveals, and canon. These facts are immutable to the three skills in this repository unless an explicit upstream change is approved.

### 2. Scene Director

Owns `HOW TO SHOW`:

- visible task and completion condition;
- blocking and movement intent;
- performance truth;
- camera reveal permissions;
- clue budget;
- shot coverage and composition;
- anchor visibility;
- sound/rhythm intent;
- director gate.

The director may choose staging and coverage but may not silently add new world rules, abilities, motives, or plot facts.

### 3. Generation Designer

Owns `HOW TO EXECUTE`:

- world/action/camera-space translation;
- model-readable action causality;
- target and orientation locks;
- salience budget;
- scale separation;
- VFX signatures where relevant;
- continuity mode;
- composition execution;
- machine-readable final state;
- AI-readability gate.

It must preserve approved coverage instead of redesigning it.

### 4. Final GU Generation Contract

The frozen semantic handoff. Once frozen, it is the only semantic source for prompt compilation.

### 5. Prompt Compiler

Owns language adaptation only. It may merge redundant wording and express locked facts in model-readable language. It may not alter story, dialogue, beat order, shot intent, or continuity state.

## Failure routing

| Failure | Owning stage |
| --- | --- |
| Plot motivation / causality | upstream story |
| Blocking / repeated composition / anchor overexposure | scene-director |
| Model cannot parse target, motion, state, or scale | generation-designer |
| Contract is correct but prompt changes meaning | prompt-compiler |
| Contract and prompt are correct but render drifts | model/runtime variance |

Repair the owning stage rather than stacking downstream negative prompts.
