# Final GU Generation Contract

The Final GU Generation Contract is the frozen interface between approved production design and prompt compilation.

## Required concepts

- `source_atoms`: traceable approved facts or beats.
- `time_capacity_seconds`: requested generation-unit capacity.
- `scene_purpose` and `scene_question`.
- `character_objectives` and `visible_task`.
- `world_space` and `character_state`.
- `asset_binding` with explicit reference responsibilities.
- `director_intent`.
- `anchor_visibility_policy`.
- `shot_coverage`.
- `beat_chain`.
- `target_orientation`.
- `camera_contract` and `sound_contract`.
- `permissions`: `LOCK`, `GUIDE`, and `FREE` fields.
- `continuity_out`.
- blocking gates for source coverage, AI readability, and prompt compilation.

## Capacity gate

If approved material does not fit the requested duration, the compiler must stop. It may not delete action, compress approved dialogue, reorder beats, or compensate with faster editing. Split decisions belong upstream and require newly frozen contracts.

## Source coverage

When source atoms exist, every approved atom must either be represented in the generation unit or be explicitly marked as contextual/non-visible. New plot-critical facts without source lineage fail the contract.
