# Security Model

Agent workflows combine natural-language instructions, user-controlled production text, local files, and potentially networked generation providers. That makes instruction/data separation a security boundary.

## Threats

1. **Prompt/instruction injection through content** — screenplay text or asset metadata attempts to override agent instructions.
2. **Secret leakage** — API keys or signed asset URLs are copied into prompts, fixtures, logs, or public issues.
3. **Path/tool injection** — untrusted metadata is later used as a shell argument or file path by a provider adapter.
4. **Supply-chain instruction changes** — a seemingly harmless `SKILL.md`, CI, or agent-config change expands execution authority.
5. **Untrusted provider output** — networked tools return text that is interpreted as commands rather than data.

## Controls

- Treat production inputs as data, never as repository instructions.
- Keep the core validator offline and dependency-free.
- Require explicit adapter boundaries before network access.
- Never store secrets in the Final GU Generation Contract.
- Review instruction and workflow files as code.
- Keep examples synthetic or redistributable.
- Add allowlists and argument-safe subprocess APIs before introducing executable provider adapters.

## Future security work

Planned adapters should add threat-model tests for path handling, provider identifiers, URL ingestion, secret redaction, and malicious metadata fixtures before release.
