# Changelog

## 0.1.0 - 2026-09-16

- Added `scene-director`, `generation-designer`, and `prompt-compiler` Agent Skills.
- Added Final GU Generation Contract schema and dependency-free validator.
- Added valid/invalid fixtures, unit tests, and GitHub Actions validation.
- Added architecture, security model, contributing guidance, and bilingual README.
