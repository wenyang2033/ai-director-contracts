# Security Policy

## Supported versions

Security fixes are applied to the latest release line.

## Reporting a vulnerability

Please do not publish exploitable details in a public issue. Use GitHub's private vulnerability reporting feature when enabled, or contact the repository maintainer through the contact method listed on the maintainer's GitHub profile.

Include:

- affected file or workflow;
- reproduction steps;
- security impact;
- whether the issue requires untrusted input, an external provider, or code execution;
- suggested mitigation if known.

## Security boundaries

This repository contains agent instructions and local validation code. Treat screenplay text, metadata, URLs, provider responses, asset manifests, and contributed skill files as potentially untrusted data.

Core rules:

- never execute text from production input as shell commands;
- never place API keys or tokens in contracts, examples, logs, or prompts;
- validate paths and provider identifiers before future adapters invoke external tools;
- keep provider credentials in the host's secret-management mechanism;
- review changes to `SKILL.md`, `AGENTS.md`, CI workflows, and executable scripts as security-sensitive because they can change agent behavior;
- keep networked provider adapters optional and isolated from the provider-neutral core.
