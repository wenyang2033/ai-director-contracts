# AI Director Contracts

**Contract-first Agent Skills for reliable AI film direction and video-prompt compilation.**

AI video workflows often fail *between* stages: a downstream agent silently changes story facts, a prompt compiler invents camera coverage, continuity is rebuilt from prose, or every shot collapses into the same composition. AI Director Contracts turns those handoffs into explicit, reviewable contracts.

The project separates creative decisions into three reusable Agent Skills:

1. **scene-director** — converts an approved scene contract into blocking, shot coverage, composition, reveal permissions, and director gates.
2. **generation-designer** — translates approved directing into model-readable spatial, action, continuity, salience, and camera constraints without re-directing the scene.
3. **prompt-compiler** — compiles one frozen Final GU Generation Contract into one generation prompt without changing story, beat order, dialogue, or camera intent.

The core rule is simple:

> **Story decides what and why. Directing decides how the audience sees it. Generation design decides how a model can execute it. Prompt compilation only translates frozen decisions.**

## Why this exists

Most AI filmmaking repositories focus on prompt syntax or end-to-end automation. This project focuses on a narrower reliability problem: **how to stop meaning, continuity, spatial logic, and approved directing decisions from drifting as work moves through multiple agents and generation models.**

The workflow adds explicit contracts for:

- source and dialogue locks;
- scene purpose and visible task;
- shot coverage and composition change;
- anchor visibility (`STRONG`, `WEAK`, `HIDDEN`);
- blocking, target, orientation, and movement causality;
- continuity modes and reality-state inheritance;
- `LOCK / GUIDE / FREE` permissions;
- source coverage and AI-readability gates;
- a frozen final contract as the only input to prompt compilation.

## Pipeline

```text
Approved story / screenplay
        |
        v
Scene contract (WHAT + WHY)
        |
        v
scene-director
  blocking + coverage + composition + reveal controls
        |
        v
generation-designer
  model-readable world/action/camera execution
        |
        v
Final GU Generation Contract (FROZEN)
        |
        v
prompt-compiler
        |
        v
One generation-ready prompt
        |
        v
Rendered result -> reality-state review -> targeted repair
```

Downstream stages **must not silently repair upstream problems**. If a required fact is missing or contradictory, the skill returns a blocking diagnostic instead of inventing an answer.

## What makes the contracts different

### Shot Coverage Contract
A valid shot is not just a camera angle. Each principal shot states its function, subject priority, scale, depth roles, camera sector, anchor visibility, composition change, and exit state.

### Anchor Visibility Policy
A landmark can exist in the world without appearing in every shot. `STRONG`, `WEAK`, and `HIDDEN` visibility prevents persistent landmarks from hijacking composition.

### Composition Repetition Gate
The director checks for repeated visual grammar before generation design begins: repeated giant-foreground/small-background staging, centered landmarks, fake reverse shots, or unnecessary re-establishment of already-known space.

### Reality State > Plan State
When a generated take is approved, its observable final state becomes the next unit's continuity truth. Plans do not override accepted reality.

### Prompt Compiler Boundary
The compiler reads one frozen final contract. It may rephrase for model readability, but it may not add plot, delete beats, compress dialogue, redesign shots, or hide capacity problems with faster cutting.

## Repository layout

```text
ai-director-contracts/
├── skills/
│   ├── scene-director/
│   ├── generation-designer/
│   └── prompt-compiler/
├── schemas/
│   └── final-gu-generation-contract.schema.json
├── scripts/
│   └── validate_contract.py
├── tests/
│   └── test_validate_contract.py
├── examples/
│   ├── final-gu-contract.valid.json
│   └── final-gu-contract.invalid.json
├── docs/
│   ├── architecture.md
│   ├── contract.md
│   └── security-model.md
├── AGENTS.md
├── CONTRIBUTING.md
├── SECURITY.md
└── LICENSE
```

## Quick start

Clone the repository and inspect the three skills. Use them in order when the upstream artifact is available, or install an individual skill in an Agent Skills-compatible host.

Validate the included contract example:

```bash
python3 scripts/validate_contract.py examples/final-gu-contract.valid.json
```

Run tests:

```bash
python3 -m unittest discover -s tests -p 'test_*.py'
```

No API key is required for validation or tests.

## Example contract lifecycle

1. Freeze story facts and approved dialogue upstream.
2. Run `scene-director`; do not proceed until director gates pass.
3. Run `generation-designer`; translate, do not redesign.
4. Freeze the Final GU Generation Contract.
5. Validate the contract.
6. Run `prompt-compiler` against that contract only.
7. Generate a take.
8. Record the approved observable result as reality state for the next unit.
9. If a failure occurs, repair the stage that owns the failure instead of accumulating prompt patches.

## Status

`v0.1.0` — initial public contract, three skills, validator, tests, and examples.

This is an early open-source release. The contract is intentionally provider-neutral; provider adapters and additional conformance fixtures are planned separately.

## Contributing

Contributions are welcome. Please read [CONTRIBUTING.md](CONTRIBUTING.md) and keep examples redistributable and free of private production data.

## Security

Agent instruction repositories have a real trust boundary. See [SECURITY.md](SECURITY.md) and [docs/security-model.md](docs/security-model.md) before adding executable adapters or ingesting untrusted production files.

## License

MIT. See [LICENSE](LICENSE).
