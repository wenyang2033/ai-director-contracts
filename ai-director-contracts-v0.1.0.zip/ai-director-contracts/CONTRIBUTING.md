# Contributing

Thanks for helping improve AI Director Contracts.

## Principles

Contributions should make AI-film handoffs more traceable, reviewable, and portable. Keep stage ownership explicit and avoid turning the repository into a model-specific prompt collection.

## Before opening a PR

- Use only public, synthetic, or redistributable examples.
- Do not include client footage, private scripts, credentials, signed URLs, or unpublished production material.
- Keep each pull request focused on one contract, skill, validator, or documentation change.
- Add or update tests for validator behavior.
- If a required contract field changes, update schema, validator, valid/invalid fixtures, docs, and affected skills together.

Run:

```bash
python3 scripts/validate_contract.py examples/final-gu-contract.valid.json
python3 -m unittest discover -s tests -p 'test_*.py'
```

## Skill changes

Every skill directory must contain a valid `SKILL.md` with `name` and `description` frontmatter. Instructions should state ownership boundaries, required inputs, output contract, and blocking conditions.

## Design discussion

For changes that alter stage ownership, contract semantics, or continuity rules, open an issue before implementation. Describe the observed failure mode and which stage should own the fix.
