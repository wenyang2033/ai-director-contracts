# Agent Development Contract

This repository treats stage ownership as a hard invariant.

## Non-negotiable rules

1. Preserve upstream approved facts. Do not rewrite source truth in a downstream skill.
2. Keep story, directing, generation design, and prompt compilation as separate responsibilities.
3. Treat the frozen Final GU Generation Contract as the only semantic input to `prompt-compiler`.
4. Prefer a blocking diagnostic over an invented assumption.
5. Do not add provider-specific fields to the core contract unless they are isolated behind an adapter/reference layer.
6. Do not commit credentials, private scripts, client footage, unpublished screenplays, or non-redistributable examples.
7. Every change to required contract fields must update schema, validator, examples, tests, and documentation in the same pull request.

## Change ownership

- Story causality / approved dialogue -> upstream story layer, outside this repository's three public skills.
- Blocking / shot coverage / reveal permissions -> `scene-director`.
- Model readability / action causality / continuity execution -> `generation-designer`.
- Natural-language generation request -> `prompt-compiler`.
- Contract syntax / gates -> schema + validator.

Do not fix an upstream defect by accumulating downstream prompt bans.
