import importlib.util
import json
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location("validate_contract", ROOT / "scripts" / "validate_contract.py")
MODULE = importlib.util.module_from_spec(SPEC)
assert SPEC and SPEC.loader
SPEC.loader.exec_module(MODULE)


class ContractValidationTests(unittest.TestCase):
    def load(self, name):
        return json.loads((ROOT / "examples" / name).read_text(encoding="utf-8"))

    def test_valid_fixture_passes(self):
        self.assertEqual(MODULE.validate_contract(self.load("final-gu-contract.valid.json")), [])

    def test_invalid_fixture_fails(self):
        errors = MODULE.validate_contract(self.load("final-gu-contract.invalid.json"))
        self.assertTrue(errors)
        self.assertIn("status must be FROZEN", errors)
        self.assertIn("gates.prompt_compiler_permission must be PASS", errors)

    def test_duplicate_source_atom_ids_fail(self):
        data = self.load("final-gu-contract.valid.json")
        data["source_atoms"].append(dict(data["source_atoms"][0]))
        errors = MODULE.validate_contract(data)
        self.assertIn("duplicate source atom id: S01", errors)


if __name__ == "__main__":
    unittest.main()
